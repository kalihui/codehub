#!/usr/bin/env Rscript
args=commandArgs();
cat("Arguments are", args, "\n")
input_filepath=args[6]
output_filepath = args[7]

#if read_length is 1, resolution is 10. otherwise it is 100.
#resolution=100
#cat("Resolution is", resolution, "\n")

library(glmnet)
library(MASS)
r=read.delim(input_filepath)
#occurrence = as.integer(r$occurrence/resolution)

#gc_ratio_array=rep(r$gcRatio, r$occurrence)
gc_ratio_array = r$gcRatio
x=cbind(gc_ratio_array, gc_ratio_array^2, gc_ratio_array^3, gc_ratio_array^4, gc_ratio_array^5)
#set the first axis to 0, use higher-order
#x[,1]=0;

#y = rep(r$readCount, r$occurrence)
y = r$readCount
median_read_count = median(rep(r$readCount, r$occurrence))
cat("median_read_count", median_read_count, "\n")
cat("no_of_data_points", length(y), "\n")

#y = (y-median_read_count)/sqrt(var(y))
##y=y/sqrt(var(y))

#normalize variance of X to 1
#for(i in 1:5 ) {
#    x[,i] = x[,i]/sqrt(var(x[,i]))
#}
glmnet_alpha=0.5
max_no_of_iterations=100000
cat("Doing cv.glmnet alpha=", glmnet_alpha, " ...")
glmnet_cv = cv.glmnet(x=x, y=y, family="poisson", alpha=glmnet_alpha, weights=r$occurrence, maxit=max_no_of_iterations);
cat("\n")
cat("glmnet_cv$lambda.1se", glmnet_cv$lambda.1se, "\n")
cat("glmnet_cv$lambda.min", glmnet_cv$lambda.min, "\n")
warnings()

cat("Doing glmnet fit ...")
glmnet_fit = glmnet(x=x, y=y, family="poisson", alpha=glmnet_alpha, lambda=glmnet_cv$lambda.1se, weights=r$occurrence,
    maxit=max_no_of_iterations);
cat("\n")
warnings()

glmnet_coeffs = coefficients(glmnet_fit, glmnet_cv$lambda.1se)[,1];
beta_selected=(abs(glmnet_fit$beta[,1])>1e-2);
#always include the first predictor (gc_ratio_array)
#beta_selected[1]=T;

#pre-pend the intercept
coeff_selected=c(T, beta_selected);

cat("glmnet_coeffs", glmnet_coeffs, "\n")
cat("coeff_selected", coeff_selected, "\n")

#back to original scale
#gc_ratio_array=r$gcRatio
#x=cbind(gc_ratio_array, gc_ratio_array^2, gc_ratio_array^3, gc_ratio_array^4, gc_ratio_array^5)
x[,!beta_selected]=0;
y=r$readCount;
data = data.frame(y=y, x1=x[,1], x2=x[,2], x3=x[,3], x4=x[,4], x5=x[,5])
cat("Doing simple linear model fit ...")
reg_lm=lm(y ~ x1+x2+x3+x4+x5, data=data, weights=r$occurrence);
lm_coeffs=rep(0,6)
lm_coeffs[coeff_selected]=reg_lm$coefficients[coeff_selected]
cat("\n")
cat("coeffs_of_lm", lm_coeffs, "\n")


#generalized linear model, negative binomial
#http://data.library.virginia.edu/getting-started-with-negative-binomial-regression-modeling/
#cat("Doing glm negative binomial fit ...")
#reg_glm_nb=glm.nb(y ~ x1+x2+x3+x4+x5, data=data, weights=r$occurrence);
#glm_nb_coeffs = rep(0,6)
#glm_nb_coeffs[coeff_selected] = reg_glm_nb$coefficients[coeff_selected]
#cat("\n")
#cat("coeffs_of_glm_nb", glm_nb_coeffs, "\n")



sink(output_filepath)
cat("coef(glmnet_fit)", glmnet_coeffs, "\n")
cat("median_read_count", median_read_count, "\n")
cat("coeff_selected", coeff_selected, "\n")
cat("coeffs_of_lm", lm_coeffs, "\n")
#cat("coeffs_of_glm_nb", glm_nb_coeffs, "\n")
cat("no_of_data_points", length(y), "\n")
cat("raw_coeffs_of_lm", reg_lm$coefficients, "\n")
#cat("raw_coeffs_of_glm_nb", reg_glm_nb$coefficients, "\n")
cat("glmnet_alpha", glmnet_alpha, "\n")
cat("glmnet_cv$lambda.1se", glmnet_cv$lambda.1se, "\n")
cat("glmnet_cv$lambda.min", glmnet_cv$lambda.min, "\n")
cat("glmnet_cv$lambda", glmnet_cv$lambda, "\n")

cat("test_gc_ratio", "coverage_by_glmnet", "coverage_by_gaussian");
#, "coverage_by_NB", "coverage_var_by_NB", "\n");

for (i in 0:10)
{
    test_gc_ratio = i/10.0;
    test_gc_vec = rbind(1, test_gc_ratio, test_gc_ratio^2, test_gc_ratio^3, test_gc_ratio^4, test_gc_ratio^5);
    coverage_by_glmnet = exp(sum(coef(glmnet_fit, s =glmnet_cv$lambda.1se )*test_gc_vec));
    coverage_by_gaussian <- sum(lm_coeffs*test_gc_vec);
    #coverage_by_NB <- exp(sum(glm_nb_coeffs*test_gc_vec));
    #coverage_variance_by_NB = coverage_by_NB + coverage_by_NB^2 / reg_glm_nb$theta;
    cat(test_gc_ratio, coverage_by_glmnet, coverage_by_gaussian, "\n");
    #coverage_by_NB, coverage_variance_by_NB, "\n")
}


cat("\n#####glmnet_cv\n")
glmnet_cv
cat("\n#####glmnet_fit\n")
glmnet_fit
cat("\n#####summary(linear_model)\n")
summary(reg_lm)
cat("\n#####anova(linear_model)\n")
anova(reg_lm)
#cat("\n#####summary(negative_binomial_model)\n")
#summary(reg_glm_nb)
#cat("\n#####anova(negative_binomial_model)\n")
#anova(reg_glm_nb)