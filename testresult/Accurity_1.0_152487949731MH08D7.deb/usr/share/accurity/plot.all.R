#!/usr/bin/env Rscript
args=commandArgs();
cat(args)
cat("\n")
configure_filepath=args[6]
sample_name=args[7]
output_dir=args[8]
output_filepath=args[9]


infer_out_df=readLines(paste(output_dir, "/infer.out.tsv",sep=""))
infer_details_df=readLines(paste(output_dir, "/infer.out.details.tsv",sep=""))
cnv_df=read.delim(paste(output_dir,"/cnv.output.tsv",sep=""),head=TRUE)
rc_ratio_window_count_df=read.delim(paste(output_dir, "/rc_ratio_window_count_smoothed.tsv",sep=""),head=TRUE)
peaks_bound_df=read.delim(paste(output_dir, "/peak_bounds.tsv",sep=""),head=TRUE)
autocor_df=read.delim(paste(output_dir, "/auto.tsv",sep=""),head=TRUE)
#sub_peak_df=readLines(paste(output_dir, "/sub_peaks.final.tsv",sep=""))
#sub_df=read.delim(paste(output_dir, "/sub.tsv",sep=""),head=TRUE)

configDataFrame=read.delim(configure_filepath, header=FALSE)
path_bin=configDataFrame[8,2]
chr_breaks_cumulative=read.table(paste(path_bin,"breaks",sep="/"))
chr_breaks=read.table(paste(path_bin,"breaks_cm",sep="/"))
chr_breaks=chr_breaks+chr_breaks_cumulative[1:22,]

library(ggplot2)
library(grid)
library(scales)

hg=c(251,244,199,193,182,172,160,147,143,137,136,135,116,108,104,91,83,79,60,64,49,52)

new_theme <- theme_set(theme_bw())
new_theme <- theme_update(
    plot.title = element_text(colour="black",size=28,angle=0,hjust=0.5,vjust=1,face="plain"),
    plot.margin = unit(c(.25, .25, .25, .25),'in'), # top, right, bottom, left
    axis.title.x = element_text(colour="black",size=16,angle=0,hjust=.5,vjust=.5,face="plain"),
    axis.title.y = element_text(colour="black",size=16,angle=90,hjust=.5,vjust=.5,face="plain")
)

theme_set(theme_bw())
theme_set(new_theme)

xmin=0;
xmax=sum(hg[1:22])*1e6;
ylim=c(-0.1,20)
ylim2=c(0,5)
min_width=5e6


for(c in 2:22) {
	shift=sum(hg[1:(c-1)])*1e6
	select=cnv_df[,1]==as.character(c);
	cnv_df[select,11:12]=cnv_df[select,11:12]+shift;
}

mylog<-function(a) {
    t=!is.na(a) & a>2
    a[t]=log2(a[t]-1)+2
    return(a);
}

myexp <- function(a) {
    t=!is.na(a) & a>2
    a[t]=2**(a[t]-2)+1
    return(a);
}

mylog2<-function(a) {
    a=a*4-2
    t=!is.na(a) & a>2
    a[t]=log2(a[t]-1)+2
    return(a);
}

myexp2<- function(a) {
    t=!is.na(a) & a>2
    a[t]=2**(a[t]-2)+1
    a=(a+2)/4
    return(a);
}

y_axis_value_for_text=seq(1,0,-0.06)
#result_summary_text=c("final estimation",infer_out_df,"","subclone fractions",sub_peak_df,"","details",infer_details_df)
result_summary_text=c(infer_out_df,"","details",infer_details_df)
result_summary_text = gsub("\t", "  ", result_summary_text)
t_len=length(result_summary_text)

grey_area1=data.frame(xmin=c(xmin),xmax=c(xmax),ymin=c(1.5),ymax=c(2.5))
grey_area2=data.frame(xmin=c(xmin),xmax=c(xmax),ymin=c(0.7955365),ymax=c(1.257013))

y_axis_copy_number_breaks=c(0:6,8,10,12,16,20)

#pdf(file=output_filepath, onefile=TRUE, paper="special",width=24,height=20)
jpeg(file=output_filepath, quality=100, width=1024, height=1024)

vplayout <- function(x, y) viewport(layout.pos.row=x, layout.pos.col=y)
grid.newpage()
pushViewport(viewport(layout=grid.layout(8, 10)))


cat("Plotting CNV ...\n")
sl=is.na(cnv_df[,5])
absolute_cnv_df=cnv_df[!sl,]
float_cnv_df=cnv_df[sl,]
p_absolute_copy_number=ggplot() +
    geom_rect(data=float_cnv_df,aes(xmin=float_cnv_df$start,xmax=pmax(float_cnv_df$end, float_cnv_df$start+min_width),ymin=myexp(mylog(float_cnv_df$cp)-0.06), ymax=myexp(mylog(float_cnv_df$cp)+0.06)),fill="green",alpha=0.7) +
    geom_rect(data=absolute_cnv_df, aes(xmin=absolute_cnv_df$start, xmax=pmax(absolute_cnv_df$end, absolute_cnv_df$start+min_width), ymin=myexp(mylog(absolute_cnv_df$cp)-0.06), ymax=myexp(mylog(absolute_cnv_df$cp)+0.06)), fill="red", alpha=0.7) +
    labs(title=paste("Accurity on ", sample_name, sep="")) +
    xlab("Chromosome number")+
    scale_x_continuous(breaks=chr_breaks$V1,labels=c(paste("",1:22,sep="")))+
    geom_vline(aes(xintercept=chr_breaks_cumulative$V1), data=chr_breaks_cumulative,color="grey",size=0.7)+
    ylab("Absolute copy number")+
    coord_trans(y=trans_new("int_log",mylog,myexp)) +
    scale_y_continuous(breaks=y_axis_copy_number_breaks,limits=ylim);
    #geom_rect(data=grey_area1,aes(xmin=xmin,xmax=xmax,ymin=ymin,ymax=ymax),fill="grey",alpha=0.4) +

cat("Plotting major allele copy number ...\n")
p_major_allele_copy_number=ggplot() +
    geom_rect(data=absolute_cnv_df, aes(xmin=absolute_cnv_df$start,xmax=pmax(absolute_cnv_df$end, absolute_cnv_df$start+min_width), ymin=myexp(mylog(absolute_cnv_df$major_allele_cp)-0.06),ymax=myexp(mylog(absolute_cnv_df$major_allele_cp)+0.06)),fill="black",alpha=0.7) +
    xlab("Chromosome number")+
    scale_x_continuous(breaks=chr_breaks$V1,labels=c(paste("",1:22,sep="")))+
    geom_vline(aes(xintercept=chr_breaks_cumulative$V1),data=chr_breaks_cumulative,color="grey",size=0.7)+
    ylab("Major allele copy number")+
    coord_trans(y=trans_new("int_log",mylog,myexp)) +
    scale_y_continuous(breaks=y_axis_copy_number_breaks,limits=ylim);
    #geom_rect(data=grey_area1,aes(xmin=xmin,xmax=xmax,ymin=ymin,ymax=ymax),fill="grey",alpha=0.4) +


cat("Plotting major allele fraction ...\n")
p_major_allele_fraction=ggplot() +
    geom_rect(data=cnv_df,aes(xmin=cnv_df$cumu_start,xmax=cnv_df$cumu_end,ymin=cnv_df$mean_maf-2*cnv_df$maf_stddev,ymax=cnv_df$mean_maf+2*cnv_df$maf_stddev),fill="green",alpha=0.5) +
    geom_segment(aes(x=cnv_df$cumu_start,y=cnv_df$maf_expected,xend=cnv_df$cumu_end,yend=cnv_df$maf_expected),data=cnv_df,size=2,color="red",alpha=0.7) +
    geom_vline(aes(xintercept=V1),data=chr_breaks_cumulative,color="grey",size=0.7) +
    scale_x_continuous(breaks=chr_breaks$V1,labels=c(paste("",1:22,sep=""))) +
    xlab("Chromosome number")+
    ylab("Major allele fraction")

cat("Plotting rc_ratio histogram ...\n")
Ymax=max(rc_ratio_window_count_df$window_count_smoothed)
p_rc_ratio_histogram=ggplot()+
    geom_area(aes(read_count_ratio, window_count_smoothed),data=rc_ratio_window_count_df)+
    geom_rect(aes(NULL,NULL,xmin=lowerBound, xmax=upperBound),data=peaks_bound_df,ymin=0,ymax=Ymax,fill="red",alpha=0.3)+
    xlab("TRE")+
    ylab("Histogram")

cat("Plotting rc_ratio autocor ...\n")
p_rc_ratio_autocorr=ggplot()+
    geom_area(aes(read_count_ratio, correlation),data=autocor_df)+
    xlab("TRE")+
    ylab("Autocorrelation")

#cat("Plotting subpeak histogram ...\n")
#p_subpeak=ggplot()+
#    geom_area(aes(V1,V2),data=sub_df)+
#    labs(title="sub histogram")

cat("Plotting summary result ...\n")
tx=data.frame(x=rep(0,t_len),y=y_axis_value_for_text[1:t_len],lb=result_summary_text)
p_summary_text=ggplot()+
    geom_text(aes(x, y, label=lb),data=tx,hjust=0,size=5)+
    scale_y_continuous(limits=c(0,1))+
    scale_x_continuous(limits=c(0,1))+
    element_blank()

print(p_summary_text, vp=vplayout(1:2,8:10))
print(p_absolute_copy_number, vp=vplayout(1:2,1:7))
print(p_major_allele_copy_number, vp=vplayout(3:4,1:7))
print(p_major_allele_fraction, vp=vplayout(5:6,1:7))
print(p_rc_ratio_histogram, vp=vplayout(3:4,8:10))
print(p_rc_ratio_autocorr, vp=vplayout(5:6,8:10))
#print(p_subpeak, vp=vplayout(7:8,8:10))
dev.off()
