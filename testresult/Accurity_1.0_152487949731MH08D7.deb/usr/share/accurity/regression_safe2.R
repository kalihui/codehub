#!/usr/bin/env Rscript
args=commandArgs();
configure_filepath=args[6]
input_filepath=args[7]
output_filepath = args[8]
para=read.table(configure_filepath)

if(para[2,2]==1) resolution=10 else resolution=100
print(resolution)
library(glmnet)
library(MASS)
r=read.delim(input_filepath)
r$gcRatio = r[,1]
r$readCount = r[,2]
r$occurrence=r[,3]
mdn=median(r$occurrence)
print(mdn)
occurrence=as.integer(r$occurrence/resolution)
b=rep(r$gcRatio,occurrence)
x=rbind(b,b^2,b^3,b^4,b^5,b^6)
for(i in 1:6 ) x[i,]=x[i,]/sqrt(var(x[i,]))
y=rep(r$readCount,occurrence)
mn=mean(y)
y=(y-mean(y))/sqrt(var(y))
##y=y/sqrt(var(y))
print(length(y))
cvobs=cv.glmnet(t(x),y)
fit=glmnet(t(x),y)
for(i in 1:length(cvobs$lambda)) { if(fit$lambda[i]<cvobs$lambda.1se){break} }
selection=(abs(fit$beta[,i])>1e-2);
selection[1]=T;
b=r$gcRatio
x=rbind(b,b^2,b^3,b^4,b^5,b^6)
x[!selection,]=0;
y=r$readCount
##reg=lm(y ~ x[1,]+ x[2,]+ x[3,]+ x[4,]+ x[5,] +x[6,],  weights=r$occurrence)
reg2=lm(as.integer(y) ~ x[1,]+ x[2,]+ x[3,]+ x[4,]+ x[5,] +x[6,], weights=r$occurrence)
reg=reg2
#reg=glm.nb(as.integer(y) ~ x[1,]+ x[2,]+ x[3,]+ x[4,]+ x[5,] +x[6,], weights=r$occurrence)
b=rep(0,7)
selection2=c(T,selection)
b[selection2]=reg$coefficients[selection2]
write(b,output_filepath)
write(mn,output_filepath,append=T)
write(summary(reg2)$r.squared,output_filepath,append=T)
write(anova(reg2)$'Pr(>F)',output_filepath,append=T)
